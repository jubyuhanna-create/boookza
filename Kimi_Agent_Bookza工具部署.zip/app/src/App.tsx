import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Sparkles, MessageCircle, Type, Laugh, Palette, Menu, X, Copy, Check, RotateCcw } from 'lucide-react';

// Simple ASCII art patterns for letters
const asciiPatterns: { [key: string]: string[] } = {
  'a': [
    '  ___  ',
    ' / _ \ ',
    '/ /_\ \\',
    '|  _  |',
    '| | | |',
    '\_| |_/' 
  ],
  'b': [
    '______ ',
    '| ___ \\',
    '| |_/ /',
    '| ___ \\',
    '| |_/ /',
    '\____/ '
  ],
  'c': [
    ' _____ ',
    '/  __ \\',
    '| /  \/',
    '| |    ',
    '| \__/\\',
    ' \____/'
  ],
  'd': [
    '______ ',
    '|  _  \\',
    '| | | |',
    '| | | |',
    '| |_| |',
    '|_____/'
  ],
  'e': [
    ' _____ ',
    '|  ___|',
    '| |__  ',
    '|  __| ',
    '| |___ ',
    '\____/'
  ],
  'f': [
    '______',
    '|  ___|',
    '| |_   ',
    '|  _|  ',
    '| |    ',
    '\_|    '
  ],
  'g': [
    ' _____ ',
    '|  __ \\',
    '| |  \/',
    '| | __ ',
    '| |_\ \\',
    ' \____/'
  ],
  'h': [
    ' _   _ ',
    '| | | |',
    '| |_| |',
    '|  _  |',
    '| | | |',
    '\_| |_/' 
  ],
  'i': [
    ' _____ ',
    '|_   _|',
    '  | |  ',
    '  | |  ',
    ' _| |_ ',
    '|_____|'
  ],
  'j': [
    '   ___ ',
    '  |_  |',
    '    | |',
    '    | |',
    '/\__/ /',
    '\____/ '
  ],
  'k': [
    ' _   __',
    '| | / /',
    '| |/ / ',
    '|    \ ',
    '| |\  \\',
    '\_| \_/' 
  ],
  'l': [
    ' _     ',
    '| |    ',
    '| |    ',
    '| |    ',
    '| |____',
    '|_____/'
  ],
  'm': [
    '___  ___',
    '|  \/  |',
    '| .  . |',
    '| |\/| |',
    '| |  | |',
    '\_|  |_/' 
  ],
  'n': [
    ' _   _ ',
    '| \ | |',
    '|  \| |',
    '| . ` |',
    '| |\  |',
    '\_| \_/' 
  ],
  'o': [
    ' _____ ',
    '|  _  |',
    '| | | |',
    '| | | |',
    '| |_| |',
    '|_____/'
  ],
  'p': [
    '______ ',
    '| ___ \\',
    '| |_/ /',
    '|  __/ ',
    '| |    ',
    '\_|    '
  ],
  'q': [
    ' _____ ',
    '|  _  |',
    '| | | |',
    '| | | |',
    '| |_| |',
    ' \__\_\\'
  ],
  'r': [
    '______ ',
    '| ___ \\',
    '| |_/ /',
    '|    / ',
    '| |\ \ ',
    '\_| \_|'
  ],
  's': [
    ' _____ ',
    '/  ___|',
    '\ `--. ',
    ' `--. \\',
    '/\__/ /',
    '\____/ '
  ],
  't': [
    ' _____ ',
    '|_   _|',
    '  | |  ',
    '  | |  ',
    '  | |  ',
    '  \_/  '
  ],
  'u': [
    ' _   _ ',
    '| | | |',
    '| | | |',
    '| | | |',
    '| |_| |',
    ' \___/ '
  ],
  'v': [
    ' _   _ ',
    '| | | |',
    '| | | |',
    '| | | |',
    '  / /  ',
    ' /_/   '
  ],
  'w': [
    ' _    _ ',
    '| |  | |',
    '| |  | |',
    '| |  | |',
    '  / /   ',
    ' / /    '
  ],
  'x': [
    '       ',
    '  / /  ',
    '   /   ',
    '  / /  ',
    '       ',
    '       '
  ],
  'y': [
    ' _   _ ',
    '| | | |',
    '| |_| |',
    ' \__  |',
    '   / / ',
    '  /_/  '
  ],
  'z': [
    '______',
    '|___  |',
    '   / / ',
    '  / /  ',
    ' / /___',
    '|_____|'
  ],
  ' ': [
    '  ',
    '  ',
    '  ',
    '  ',
    '  ',
    '  '
  ],
  '0': [
    ' _____ ',
    '|  _  |',
    '| | | |',
    '| | | |',
    '| |_| |',
    '|_____|' 
  ],
  '1': [
    ' __  ',
    '/  | ',
    '   | ',
    '   | ',
    '_  |_',
    '|____|'
  ],
  '2': [
    ' _____ ',
    '/ __  |',
    '    / /',
    '   / / ',
    '  / /__',
    ' |_____|'
  ],
  '3': [
    ' _____ ',
    '|____ |',
    '    / /',
    '    / /',
    '  / /  ',
    ' /_/   '
  ],
  '4': [
    '   ___ ',
    '  /   |',
    ' / /| |',
    '/ /_| |',
    '    | |',
    '    |_/ '
  ],
  '5': [
    ' _____ ',
    '|  ___|',
    '|___  |',
    '     |',
    '  / /  ',
    ' /_/   '
  ],
  '6': [
    '  __  ',
    ' / _| ',
    '/ /__ ',
    '|  _  |',
    '| |_| |',
    ' \____/'
  ],
  '7': [
    '______',
    '|___  |',
    '   / / ',
    '  / /  ',
    ' / /   ',
    '/_/    '
  ],
  '8': [
    ' _____ ',
    '|  _  |',
    '  / /  ',
    ' / /   ',
    '| |_| |',
    '|_____|'
  ],
  '9': [
    ' _____ ',
    '|  _  |',
    '| |_| |',
    '|____ |',
    '   / / ',
    '  /_/  '
  ],
  '!': [
    ' _ ',
    '| |',
    '| |',
    '| |',
    '|_|',
    '(_)'
  ],
  '?': [
    ' ___ ',
    '|__ |',
    '   ) |',
    '  / / ',
    ' |_|  ',
    ' (_)  '
  ]
};

// Funny Name Generator Data
const funnyFirstNames = [
  'Bubbles', 'Wobble', 'Snickers', 'Fuzzy', 'Zippy', 'Noodle', 'Biscuit', 'Wiggles', 
  'Giggles', 'Pickle', 'Muffin', 'Squishy', 'Dizzy', 'Jelly', 'Popcorn', 'Twinkle',
  'Squeaky', 'Bouncy', 'Fluffy', 'Wacky', 'Zany', 'Quirky', 'Silly', 'Goofy',
  'Chuckles', 'Tater', 'Nugget', 'Pudding', 'Cookie', 'Sprinkles', 'Marshmallow',
  'Bubblegum', 'Cotton', 'Candy', 'Lollipop', 'Gummy', 'Bear', 'Cupcake', 'Donut'
];

const funnyLastNames = [
  'McFlufferson', 'Wobblebottom', 'Gigglepants', 'Snickerdoodle', 'Fuzzlewump',
  'Zippitydoo', 'Noodleton', 'Biscuitworth', 'Wigglesworth', 'Picklebottom',
  'Muffintop', 'Squishypants', 'Dizzydoodle', 'Jellybean', 'Popcornicus',
  'Twinkletoes', 'Squeakerson', 'Bouncypants', 'Fluffernutter', 'Wackydoo',
  'Zanypants', 'Quirkleton', 'Sillypants', 'Goofball', 'Chucklesworth',
  'Tatertot', 'Nuggetson', 'Puddingworth', 'Cookiemonster', 'Sprinkleton',
  'Marshmallowbottom', 'Bubblegump', 'Cottoncandy', 'Lollipop', 'Gummybear'
];

// Emoji mapping
const emojiMap: { [key: string]: string } = {
  'a': '🍎', 'b': '🐝', 'c': '🐱', 'd': '🐶', 'e': '🥚', 'f': '🌸', 'g': '🍇', 'h': '🏠',
  'i': '🍦', 'j': '🤹', 'k': '🔑', 'l': '🦁', 'm': '🌙', 'n': '📰', 'o': '🐙', 'p': '🍕',
  'q': '👸', 'r': '🌈', 's': '🌟', 't': '🌴', 'u': '☂️', 'v': '🎻', 'w': '🍉', 'x': '❌',
  'y': '🧘', 'z': '🦓', ' ': '✨', '!': '❗', '?': '❓', '.': '🔵', ',': '🌸'
};

// Jokes database
const jokes = [
  "Why don't scientists trust atoms? Because they make up everything!",
  "Why did the scarecrow win an award? He was outstanding in his field!",
  "Why don't eggs tell jokes? They'd crack each other up!",
  "What do you call a fake noodle? An impasta!",
  "Why did the math book look so sad? Because it had too many problems.",
  "What do you call a bear with no teeth? A gummy bear!",
  "Why did the cookie go to the doctor? Because it was feeling crumbly!",
  "What do you get when you cross a snowman with a vampire? Frostbite!",
  "Why don't skeletons fight each other? They don't have the guts!",
  "What do you call a sleeping dinosaur? A dino-snore!",
  "Why did the tomato turn red? Because it saw the salad dressing!",
  "What do you call a fish with no eyes? Fsh!",
  "Why did the golfer bring two pairs of pants? In case he got a hole in one!",
  "What do you call a can opener that doesn't work? A can't opener!",
  "Why did the invisible man turn down the job offer? He couldn't see himself doing it!",
  "What do you get when you cross a snowman and a dog? Frostbite!",
  "Why did the bicycle fall over? Because it was two-tired!",
  "What do you call a boomerang that doesn't come back? A stick!",
  "Why don't oysters donate to charity? Because they're shellfish!",
  "What do you call a pile of cats? A meowtain!",
  "Why did the coffee file a police report? It got mugged!",
  "What do you call a belt made of watches? A waist of time!",
  "Why did the banana go to the doctor? It wasn't peeling well!",
  "What do you call a dinosaur with an extensive vocabulary? A thesaurus!",
  "Why did the stadium get hot after the game? All the fans left!",
  "What do you call a fish wearing a crown? A king fish!",
  "Why did the music teacher go to jail? Because she got caught with sharp objects!",
  "What do you call a sleeping bull? A bulldozer!",
  "Why did the picture go to jail? Because it was framed!",
  "What do you call a group of unorganized cats? A cat-astrophe!"
];

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Funny Name Generator State
  const [funnyName, setFunnyName] = useState('');

  // Emoji Text Generator State
  const [emojiInput, setEmojiInput] = useState('');
  const [emojiOutput, setEmojiOutput] = useState('');

  // Word Counter State
  const [wordCountText, setWordCountText] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);

  // Joke Generator State
  const [currentJoke, setCurrentJoke] = useState('');

  // ASCII Art State
  const [asciiInput, setAsciiInput] = useState('');
  const [asciiOutput, setAsciiOutput] = useState('');

  // Scroll to section
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  // Funny Name Generator Functions
  const generateFunnyName = () => {
    const first = funnyFirstNames[Math.floor(Math.random() * funnyFirstNames.length)];
    const last = funnyLastNames[Math.floor(Math.random() * funnyLastNames.length)];
    setFunnyName(`${first} ${last}`);
  };

  // Emoji Text Generator Functions
  const convertToEmoji = () => {
    const converted = emojiInput.toLowerCase().split('').map(char => emojiMap[char] || char).join(' ');
    setEmojiOutput(converted);
  };

  // Word Counter Functions
  const handleWordCountChange = (text: string) => {
    setWordCountText(text);
    setCharCount(text.length);
    const words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
    setWordCount(words);
  };

  const resetWordCounter = () => {
    setWordCountText('');
    setWordCount(0);
    setCharCount(0);
  };

  // Joke Generator Functions
  const generateJoke = () => {
    const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
    setCurrentJoke(randomJoke);
  };

  // ASCII Art Functions - Simple built-in generator
  const generateAsciiArt = () => {
    if (!asciiInput.trim()) return;
    
    const text = asciiInput.toLowerCase().slice(0, 15);
    const letters: string[][] = [];
    
    for (const char of text) {
      const pattern = asciiPatterns[char];
      if (pattern) {
        letters.push(pattern);
      }
    }
    
    if (letters.length === 0) {
      setAsciiOutput('Please enter valid characters (a-z, 0-9, !, ?)');
      return;
    }
    
    // Combine letters horizontally
    const lines: string[] = [];
    for (let i = 0; i < 6; i++) {
      let line = '';
      for (const letter of letters) {
        line += letter[i] || '';
      }
      lines.push(line);
    }
    
    setAsciiOutput(lines.join('\n'));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Initialize on mount
  useEffect(() => {
    generateFunnyName();
    generateJoke();
  }, []);

  const navLinks = [
    { id: 'name-generator', label: 'Funny Name', icon: Sparkles },
    { id: 'emoji-generator', label: 'Emoji Text', icon: MessageCircle },
    { id: 'word-counter', label: 'Word Counter', icon: Type },
    { id: 'joke-generator', label: 'Jokes', icon: Laugh },
    { id: 'ascii-generator', label: 'ASCII Art', icon: Palette },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md shadow-lg border-b border-purple-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Sparkles className="h-8 w-8 text-purple-600" />
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Bookza Fun Tools
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="flex items-center space-x-1 px-4 py-2 rounded-lg text-gray-700 hover:bg-purple-100 hover:text-purple-700 transition-all duration-200"
                >
                  <link.icon className="h-4 w-4" />
                  <span className="text-sm font-medium">{link.label}</span>
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-purple-100 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6 text-purple-600" /> : <Menu className="h-6 w-6 text-purple-600" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-purple-100">
            <div className="px-4 py-2 space-y-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="flex items-center space-x-2 w-full px-4 py-3 rounded-lg text-gray-700 hover:bg-purple-100 hover:text-purple-700 transition-all"
                >
                  <link.icon className="h-5 w-5" />
                  <span className="font-medium">{link.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="pt-20 pb-12">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-16 px-4">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 via-pink-400/20 to-blue-400/20 animate-pulse" />
          <div className="relative max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
              Welcome to Bookza Fun Tools! 🎉
            </h1>
            <p className="text-lg md:text-xl text-gray-600 mb-8">
              Your one-stop destination for fun, creativity, and entertainment! 
              Explore our collection of free online tools.
            </p>
            
            {/* AdSense Placeholder */}
            <div className="max-w-2xl mx-auto mb-8 p-4 bg-gray-100 rounded-xl border-2 border-dashed border-gray-300">
              <p className="text-sm text-gray-500 mb-2">Advertisement</p>
              <div className="h-24 flex items-center justify-center text-gray-400">
                Google AdSense Ad Placeholder
              </div>
            </div>
          </div>
        </section>

        {/* Funny Name Generator */}
        <section id="name-generator" className="py-16 px-4 bg-gradient-to-br from-pink-50 to-rose-100">
          <div className="max-w-4xl mx-auto">
            <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full">
                    <Sparkles className="h-8 w-8 text-white" />
                  </div>
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">Funny Name Generator</CardTitle>
                <CardDescription className="text-gray-600">
                  Generate hilarious and unique names for any occasion!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-gradient-to-r from-pink-100 to-rose-100 rounded-2xl p-8 text-center">
                  <p className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-2">
                    {funnyName}
                  </p>
                </div>
                <div className="flex justify-center">
                  <Button
                    onClick={generateFunnyName}
                    className="bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-8 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <Sparkles className="h-5 w-5 mr-2" />
                    Generate New Name
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Emoji Text Generator */}
        <section id="emoji-generator" className="py-16 px-4 bg-gradient-to-br from-yellow-50 to-orange-100">
          <div className="max-w-4xl mx-auto">
            <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full">
                    <MessageCircle className="h-8 w-8 text-white" />
                  </div>
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">Emoji Text Generator</CardTitle>
                <CardDescription className="text-gray-600">
                  Transform your text into a fun emoji-filled message!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Enter your text:</label>
                  <Input
                    value={emojiInput}
                    onChange={(e) => setEmojiInput(e.target.value)}
                    placeholder="Type something fun..."
                    className="text-lg p-4 rounded-xl border-2 border-yellow-200 focus:border-yellow-400 focus:ring-yellow-400"
                  />
                </div>
                <div className="flex justify-center">
                  <Button
                    onClick={convertToEmoji}
                    className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white px-8 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <MessageCircle className="h-5 w-5 mr-2" />
                    Convert to Emoji
                  </Button>
                </div>
                {emojiOutput && (
                  <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl p-6">
                    <p className="text-2xl md:text-3xl text-center break-words leading-relaxed">
                      {emojiOutput}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Quick Word Counter */}
        <section id="word-counter" className="py-16 px-4 bg-gradient-to-br from-green-50 to-emerald-100">
          <div className="max-w-4xl mx-auto">
            <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full">
                    <Type className="h-8 w-8 text-white" />
                  </div>
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">Quick Word Counter</CardTitle>
                <CardDescription className="text-gray-600">
                  Instantly count words and characters in your text!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Textarea
                  value={wordCountText}
                  onChange={(e) => handleWordCountChange(e.target.value)}
                  placeholder="Type or paste your text here..."
                  className="min-h-[200px] text-lg p-4 rounded-xl border-2 border-green-200 focus:border-green-400 focus:ring-green-400 resize-none"
                />
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gradient-to-br from-green-100 to-emerald-100 rounded-2xl p-6 text-center">
                    <p className="text-5xl font-bold text-green-600 mb-2">{wordCount}</p>
                    <p className="text-gray-600 font-medium">Words</p>
                  </div>
                  <div className="bg-gradient-to-br from-emerald-100 to-teal-100 rounded-2xl p-6 text-center">
                    <p className="text-5xl font-bold text-emerald-600 mb-2">{charCount}</p>
                    <p className="text-gray-600 font-medium">Characters</p>
                  </div>
                </div>
                <div className="flex justify-center">
                  <Button
                    onClick={resetWordCounter}
                    variant="outline"
                    className="border-2 border-green-300 text-green-700 hover:bg-green-50 px-6 py-4 rounded-xl"
                  >
                    <RotateCcw className="h-5 w-5 mr-2" />
                    Reset
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Random Joke Generator */}
        <section id="joke-generator" className="py-16 px-4 bg-gradient-to-br from-blue-50 to-indigo-100">
          <div className="max-w-4xl mx-auto">
            <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-full">
                    <Laugh className="h-8 w-8 text-white" />
                  </div>
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">Random Joke Generator</CardTitle>
                <CardDescription className="text-gray-600">
                  Get a laugh with our collection of funny jokes!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-gradient-to-r from-blue-100 to-indigo-100 rounded-2xl p-8">
                  <p className="text-xl md:text-2xl text-center text-gray-800 leading-relaxed">
                    {currentJoke}
                  </p>
                </div>
                <div className="flex justify-center">
                  <Button
                    onClick={generateJoke}
                    className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white px-8 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <Laugh className="h-5 w-5 mr-2" />
                    Generate Joke
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* ASCII Art Text Generator */}
        <section id="ascii-generator" className="py-16 px-4 bg-gradient-to-br from-purple-50 to-violet-100">
          <div className="max-w-4xl mx-auto">
            <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-gradient-to-br from-purple-400 to-violet-500 rounded-full">
                    <Palette className="h-8 w-8 text-white" />
                  </div>
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">ASCII Art Text Generator</CardTitle>
                <CardDescription className="text-gray-600">
                  Convert your text into cool ASCII art!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Enter your text:</label>
                  <Input
                    value={asciiInput}
                    onChange={(e) => setAsciiInput(e.target.value)}
                    placeholder="Type something to convert..."
                    maxLength={15}
                    className="text-lg p-4 rounded-xl border-2 border-purple-200 focus:border-purple-400 focus:ring-purple-400"
                  />
                  <p className="text-xs text-gray-500">Maximum 15 characters (a-z, 0-9, !, ?)</p>
                </div>
                <div className="flex justify-center">
                  <Button
                    onClick={generateAsciiArt}
                    className="bg-gradient-to-r from-purple-500 to-violet-500 hover:from-purple-600 hover:to-violet-600 text-white px-8 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    <Palette className="h-5 w-5 mr-2" />
                    Generate ASCII Art
                  </Button>
                </div>
                {asciiOutput && (
                  <div className="relative bg-gray-900 rounded-2xl p-6 overflow-x-auto">
                    <button
                      onClick={() => copyToClipboard(asciiOutput)}
                      className="absolute top-4 right-4 p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                      title="Copy to clipboard"
                    >
                      {copied ? <Check className="h-5 w-5 text-green-400" /> : <Copy className="h-5 w-5 text-gray-300" />}
                    </button>
                    <pre className="text-green-400 font-mono text-xs md:text-sm leading-tight whitespace-pre">
                      {asciiOutput}
                    </pre>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Bottom Ad Placeholder */}
        <section className="py-8 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="p-4 bg-gray-100 rounded-xl border-2 border-dashed border-gray-300 text-center">
              <p className="text-sm text-gray-500 mb-2">Advertisement</p>
              <div className="h-24 flex items-center justify-center text-gray-400">
                Google AdSense Ad Placeholder
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="h-6 w-6 text-purple-400" />
                <span className="text-xl font-bold">Bookza Fun Tools</span>
              </div>
              <p className="text-gray-400 mb-4">
                Your destination for fun, creativity, and entertainment! 
                All tools are free and work instantly in your browser.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4 text-purple-400">Quick Links</h3>
              <ul className="space-y-2">
                <li><button onClick={() => scrollToSection('name-generator')} className="text-gray-400 hover:text-white transition-colors">Funny Name Generator</button></li>
                <li><button onClick={() => scrollToSection('emoji-generator')} className="text-gray-400 hover:text-white transition-colors">Emoji Text</button></li>
                <li><button onClick={() => scrollToSection('word-counter')} className="text-gray-400 hover:text-white transition-colors">Word Counter</button></li>
                <li><button onClick={() => scrollToSection('joke-generator')} className="text-gray-400 hover:text-white transition-colors">Joke Generator</button></li>
                <li><button onClick={() => scrollToSection('ascii-generator')} className="text-gray-400 hover:text-white transition-colors">ASCII Art</button></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4 text-purple-400">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="mailto:bookza.online@gmail.com" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-500">
              © {new Date().getFullYear()} Bookza Fun Tools. All rights reserved.
            </p>
            <p className="text-gray-600 text-sm mt-2">
              Contact: <a href="mailto:bookza.online@gmail.com" className="text-purple-400 hover:text-purple-300">bookza.online@gmail.com</a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
